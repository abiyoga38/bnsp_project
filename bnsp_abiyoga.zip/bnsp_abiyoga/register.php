<?php 
    include "db_config.php";

    if(isset($_POST["inputData"])){
        $nama = $_POST['nama'];
        $email = $_POST['email'];
        $nohp = $_POST['nohp'];
        $semester = $_POST['semester'];
        $ipk = $_POST['ipk'];
        $beasiswa = $_POST['beasiswa'];
        $jeniskelamin = $_POST['kelamin'];
        $berkas = $_POST['berkas'];
        $status = $_POST['status'];

        $sql = "INSERT INTO beasiswa (nama, email, nohp, semester, ipk, jenis_kelamin, jenis_beasiswa, berkas, status_pengajuan) 
        VALUES ('$nama','$email','$nohp','$semester','$ipk', '$jeniskelamin', '$beasiswa','$berkas', '$status')";
        if(mysqli_query($conn, $sql)){
            echo "<script>alert('Data berhasil ditambahkan')</script>";
            echo "<script>window.location.href = 'home.php'</script>";
        } else {
            echo "Error: ".$sql.":-".mysqli_error($conn);
        }
        mysqli_close($conn);
    }

    define('MIN_IPK', 2.0);
    define('MAX_IPK', 4.0);

    function generateIPK() {
        return number_format(mt_rand(MIN_IPK * 10, MAX_IPK * 10)/10,1);
    }

    function generateIPKMahasiswa() {
        $randomIPK = generateIPK();
        echo "".$randomIPK;
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter&display=swap" rel="stylesheet">
    <script src="function.js"></script>

</head>
<body>
    <nav class="navbar">
        <h1>Pendaftaran Beasiswa</h1>
    </nav>
    <div class="container-form">
        <form action="" method="POST" class="box-form">
            <div class="form-header">
                <p>Registrasi Beasiswa</p>
            </div>
            <div>
                <label for="nama">Masukkan Nama</label>
                <input type="text" name="nama" id="nama">
            </div>
            <div>
                <label for="email">Masukkan Email</label>
                <input type="email" name="email" id="email">
            </div>
            <div>
                <label for="kelamin">Jenis Kelamin</label>
                <select name="kelamin" id="kelamin">
                    <option value="Laki - laki">Laki - laki</option>
                    <option value="Perempuan">Perempuan</option>
                </select>
            </div>
            <div>
                <label for="nohp">Nomor Hp</label>
                <input type="number" name="nohp" id="nohp">
            </div>
            <div>
                <label for="semester">Semester saat ini</label>
                <select name="semester" id="semester">
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                    <option value="7">7</option>
                    <option value="8">8</option>
                </select>
            </div>
            <div>
                <label for="ipk">IPK Terakhir</label>
                <input type="text" name="ipk" id="ipk" value="<?php generateIPKMahasiswa() ?>" readonly="true">
            </div>
            <div>
                <label for="beasiswa">Pilihan Beasiswa</label>
                <select name="beasiswa" id="beasiswa">
                    <option value="Akademis">Akademis</option>
                    <option value="Non-Akademis">Non-Akademis</option>
                </select>
            </div>
            <div>
                <label for="berkas">Upload Berkas Syarat</label>
                <input type="file" name="berkas" id="berkas">
            </div>
            <div>
                <input type="hidden" name="status" id="status" value="Belum Verifikasi" readonly="true">
            </div>
            <div class="form-btn">
                <input type="submit" class="daftar-btn" name="inputData" id="inputData" value="Daftar">
                <a href="home.php"><input type="button" class="batal-btn" value="Batal"></a>
            </div>
        </form>
    </div>
</body>
</html>