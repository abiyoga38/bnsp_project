document.addEventListener('DOMContentLoaded', function () {
    var namaInput = document.getElementById('nama');
    var emailInput = document.getElementById('email');
    var nohpInput = document.getElementById('nohp');
    var semesterInput = document.getElementById('semester');
    var ipkInput = document.getElementById('ipk');
    var beasiswaSelect = document.getElementById('beasiswa');
    var jeniskelamin = document.getElementyById('kelamin');
    var berkasInput = document.getElementById('berkas');
    var daftarBtn = document.getElementById('inputData');

    // Menambahkan event listener untuk setiap elemen formulir
    namaInput.addEventListener('input', validateForm);
    emailInput.addEventListener('input', validateForm);
    nohpInput.addEventListener('input', validateForm);
    semesterInput.addEventListener('change', validateForm);
    ipkInput.addEventListener('input', validateForm);
    berkasInput.addEventListener('input', validateForm);

    // Fungsi untuk validasi formulir dan mengatur status formulir
    function validateForm() {
        var isFormValid = true;

        // ... (validasi lainnya)

        // Contoh validasi IPK (ganti dengan validasi sesuai kebutuhan)
        var ipkValue = parseFloat(ipkInput.value);
        if (isNaN(ipkValue) || ipkValue < 3.0 || ipkValue > 4.0) {
            isFormValid = false;
        }

        // Menonaktifkan elemen formulir jika IPK berada di bawah 3.0
        if (ipkValue < 3.0) {
            beasiswaSelect.disabled = true;
            berkasInput.disabled = true;
            daftarBtn.disabled = true;
            daftarBtn.style.background = "#A9A9A9";
        } else {
            // Jika IPK di atas 3.0, aktifkan elemen beasiswa dan set fokus pada pilihan beasiswa
            beasiswaSelect.disabled = false;
            berkasInput.disabled = false;
            daftarBtn.disabled = false;
            beasiswaSelect.blur();
        }
    }

    // Panggil fungsi validasiForm saat halaman dimuat
    validateForm();
});