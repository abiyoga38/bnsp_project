Author : Abiyoga Priambudi
Version : 1.0

Folder Structure
- assets
    - function.js
    - style.css
- config
    - db_connect.php
- view
    - home.php
    - register.php
    - result.php
    - view.php

keterangan :

- folder asset berisi file css dan javascript
- folder config berisi soal config koneksi database
- folder view berisi file - file html yang berperan sebagai front and untuk tampilan pada website