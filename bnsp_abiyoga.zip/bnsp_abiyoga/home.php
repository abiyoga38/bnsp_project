<?php 
    include "db_config.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter&display=swap" rel="stylesheet">

</head>
<body>
    <nav class="navbar">
        <h1>Pendaftaran Beasiswa</h1>
    </nav>
    <div class="container">
        <h3>SELAMAT DATANG DI</h3>
        <h2>SISTEM PENERIMAAN BEASISWA</h2>
        <button><a href="register.php">Daftar Beasiswa</a></button>
        <button><a href="hasil.php">Lihat Hasil</a></button>
    </div>
</body>
</html>