<?php 
    include("db_config.php");
    
    $db = $conn;
    $tableName = 'beasiswa';
    $column = ["id", "nama", "email", "nohp", "semester", "ipk", "jenis_kelamin", "jenis_beasiswa", "berkas", "status_pengajuan"];
    $id = isset($_GET['id']) ? $_GET['id'] : null;
    $fetchData = fetch_data($db, $tableName, $column, $id);

    function fetch_data($db, $tableName, $column, $id){
        if(empty($db)){
            $msg = "Database connection error";
        } else if(empty($column) || !is_array($column)){
            $msg = "Column name must be defined in an indexed array";
        } else if(empty($tableName)){
            $msg = "Table name is empty";
        } else {
            $columnName = implode(", ", $column);
            $query = "SELECT ".$columnName." FROM $tableName WHERE id = $id";;
            $result = $db->query($query);

            if($result==true){
                if($result->num_rows > 0){
                    $row = mysqli_fetch_assoc($result);
                    $msg = $row;
                } else {
                    $msg = "No Data Found";
                }
            } else {
                $msg = mysqli_error($db);
            }
        }
        return $msg;
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter&display=swap" rel="stylesheet">
    <script src="function.js"></script>
</head>
<body>
    <nav class="navbar">
        <h1>Pendaftaran Beasiswa</h1>
    </nav>
    <div class="container-form">
        <form action="" method="POST" class="box-form">
            <div class="form-header">
                <p>Registrasi Beasiswa</p>
            </div>
            <?php 
                if(is_array($fetchData)){
                    
            ?>
            <div>
                <input type="hidden" name="id" id="id" value="<?php echo $fetchData['id']?>">
            </div>
            <div>
                <label for="nama">Masukkan Nama</label>
                <input type="text" name="nama" id="nama" value="<?php echo $fetchData['nama']?>" readonly="true">
            </div>
            <div>
                <label for="email">Masukkan Email</label>
                <input type="email" name="email" id="email" value="<?php echo $fetchData['email']?>" readonly="true">
            </div>
            <div>
                <label for="kelamin">Jenis Kelamin</label>
                <input type="kelamin" name="email" id="email" value="<?php echo $fetchData['jenis_kelamin'] ?>">
            </div>
            <div>
                <label for="nohp">Nomor HP</label>
                <input type="number" name="nohp" id="nohp" value="<?php echo $fetchData['nohp']?>" readonly="true">
            </div>
            <div>
                <label for="semester">Semester saat ini</label>
                <select name="semester" id="semester" disabled>
                    <option value="1"><?php echo $fetchData['semester'] ?></option>
                    <option value="2"><?php echo $fetchData['semester'] ?></option>
                    <option value="3"><?php echo $fetchData['semester'] ?></option>
                    <option value="4"><?php echo $fetchData['semester'] ?></option>
                    <option value="5"><?php echo $fetchData['semester'] ?></option>
                    <option value="6"><?php echo $fetchData['semester'] ?></option>
                    <option value="7"><?php echo $fetchData['semester'] ?></option>
                    <option value="8"><?php echo $fetchData['semester'] ?></option>
                </select>
            </div>
            <div>
                <label for="ipk">IPK Terakhir</label>
                <input type="number" name="ipk" id="ipk" value="<?php echo $fetchData['ipk']?>" readonly="true">
            </div>
            <div>
                <label for="beasiswa">Pilihan Beasiswa</label>
                <select name="beasiswa" id="beasiswa" disabled>
                    <option value="Akademis"><?php echo $fetchData['jenis_beasiswa']?></option>
                    <option value="Non-Akademis"><?php echo $fetchData['jenis_beasiswa']?></option>
                </select>
            </div>
            <div>
                <label for="berkas">Upload Berkas Syarat</label>
                <input type="file" name="berkas" id="berkas" value="<?php echo $fetchData['berkas']?>">
            </div>
            <div>
                <label for="status">Status Pengajuan</label>
                <span><?php echo $fetchData['status_pengajuan'] ?></span>
            </div>
            <div class="form-btn">
                <a href="hasil.php"><input type="button" class="back-btn" id="backBtn" value="Kembali"></a>
            </div>
            <?php
                    }
            ?>
            
        </form>
    </div>
</body>
</html>