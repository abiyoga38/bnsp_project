<?php
    $server = "localhost";
    $user = "root";
    $password = "";
    $db = "db_beasiswa";

    $conn = new mysqli($server, $user, $password, $db);

    if($conn->connect_error){
        die("Connection failed: ".$conn->connect_error);
    }
    echo "<script>console.log('Berhasil Konek Database')</script>";
?>