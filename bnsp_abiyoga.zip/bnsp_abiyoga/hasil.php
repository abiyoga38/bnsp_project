<?php 
    include "db_config.php";

    $db = $conn;
    $tableName = 'beasiswa';
    $column = ["id", "nama", "email", "jenis_kelamin", "nohp", "jenis_beasiswa", "status_pengajuan"];
    $fetchData = fetch_data($db, $tableName, $column);

    function fetch_data($db, $tableName, $column){
        if(empty($db)){
            $msg = "Koneksi database error";
        } else if(empty($column) || !is_array($column)){
            $msg = "Kolom harus dalam bentuk array";
        } else if(empty($tableName)){
            $msg = "Nama tabel kosong";
        } else {
            $columnName = implode(", ", $column);
            $query = "SELECT ".$columnName." FROM $tableName";
            $result = $db->query($query);

            if($result==true){
                if($result->num_rows > 0){
                    $row = mysqli_fetch_all($result, MYSQLI_ASSOC);
                    $msg = $row;
                } else {
                    $msg = "Data tidak ditemukan";
                }
            } else {
                $msg = mysqli_error($db);
            }
        }
        return $msg;
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

</head>
<body>
    <nav class="navbar">
        <a href="home.php"><h1>Pendaftaran Beasiswa</h1></a>
    </nav>
    <div class="container-result">
        <div class="result-header">
            <a href="" class="round-icon"><i class="fa-solid fa-book"></i></a>
            <h1>Sistem Pendaftaran Beasiswa</h1>
        </div>

        <div class="table-card">
            <div class="table">
                <table>
                    <tr>
                        <th id="tnomor">No</th>
                        <th id="tnama">Nama</th>
                        <th id="temail">Email</th>
                        <th id="tjk">Jenis Kelamin</th>
                        <th id="tnohp">No. Hp</th>
                        <th id="tbeasiswa">Jenis Beasiswa</th>
                        <th id="tstatus">Status Pengajuan</th>
                        <th id="taction">Action</th>
                    </tr>
                    <?php
                        if(is_array($fetchData)){
                            foreach($fetchData as $data){
                    ?>
                    <tr>
                        <td><?php echo $data['id']?></td>
                        <td><?php echo $data['nama']?></td>
                        <td><?php echo $data['email']?></td>
                        <td><?php echo $data['jenis_kelamin']?></td>
                        <td><?php echo $data['nohp']?></td>
                        <td><?php echo $data['jenis_beasiswa']?></td>
                        <td><?php echo $data['status_pengajuan']?></td>
                        <td><a href="view.php?id=<?php echo $data['id'] ?>"><input type="button" class="view-btn" value="View"></a></td>
                    </tr>
                    <?php 
                            }}
                    ?>
                </table>
            </div>
        </div>
    </div>
</body>
</html>